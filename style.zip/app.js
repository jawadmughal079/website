$(document).ready(function () {
  $(".slider1").slick({
    arrows: false,
    dots: true,
    appendDots: ".slider1Dots",
  });
  $(".slider2").slick({
    arrows: false,
    dots: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    centerMode: true,
    appendDots: ".slider2Dots",
    autoplay: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2
        }
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      }
      // You can unslick at a given breakpoint now by adding:
      // settings: "unslick"
      // instead of a settings object
    ]
  });
  $(".slider3").slick({
    dots: true,
    arrows: false,
    appendDots: ".slider3Dots",
    centerMode: true,
    slidesToShow: 3,
    slidesToScroll: 1,
  });
});

const trigger = document.querySelectorAll(".trigger");

for (let index = 0; index < trigger.length; index++) {
  trigger[index].addEventListener("click", function (event) {
    event.preventDefault();
    this.classList.toggle("is-open");
  });
}
